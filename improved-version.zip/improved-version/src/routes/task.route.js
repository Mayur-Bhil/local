import { Router } from "express";
import  {createTask,getAllTasks}  from "../controllers/Taskcontroller.js";
import auth from "../middlewares/auth.js";
const taskRouter = Router();


taskRouter.post("/create",auth,createTask);
taskRouter.get("/getalltasks",getAllTasks)


export default taskRouter;