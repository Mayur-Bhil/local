import jwt from "jsonwebtoken";

const auth = async (req, res, next) => {
  try {
    const token =
      req?.cookies?.token ||
      (req?.headers?.authorization?.startsWith("Bearer ")
        ? req.headers.authorization.split(" ")[1]
        : null);

    if (!token) {
      return res.status(401).json({
        message: "AccessToken required. Please login",
        error: true,
        success: false,
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

    if (!decoded) {
      return res.status(401).json({
        message: "Invalid token. Please login again",
        error: true,
        success: false,
      });
    }

    req.userId = decoded.id;
    next();
  } catch (error) {
    console.log("Auth middleware error:", error);
    return res.status(500).json({
      error: error.message,
      message: "Something went wrong in authentication",
    });
  }
};

export default auth;
