import User from "../model/user.model.js";
import jwt from "jsonwebtoken"



export const createUserController = async (req,res)=>{
    try {
        const {name,email,password} = req.body;
        const existingUser = await User.findOne({
            email:email
        })

        if(existingUser){
            return res.json({
                message: "User is already exist"
            })
        }
        const newUser = await User.create({
            name:name,
            email:email,
            password
        })

        await newUser.save();

        res.json({
            message : "User Created SuccessFUlly",
            data:newUser,
            success:true,
            error:false
        })
    } catch (error) {
        return res.status(500).json({
            error: error.message,
            message: "Something went wrong"
        })
    }
}


export const signinUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email) return res.json({ message: "Enter Email" });
    if (!password) return res.json({ message: "Enter Password" });

    const user = await User.findOne({ email });
    if (!user) {
      return res.json({ message: "Invalid Credentials", success: false, error: true });
    }

    const isPasswordValid = await user.validatePassword(password);
    if (!isPasswordValid) {
      return res.json({ message: "Invalid Password", success: false, error: true });
    }

    const jwtToken = jwt.sign(
      { _id: user._id },
      process.env.JWT_SECRET_KEY,
      { expiresIn: "1d" }
    );

    const cookieOptions = {
      httpOnly: true,
      secure: false,   // ❌ set to true only in production with HTTPS
      sameSite: "Lax",
    };

    res.cookie("token", jwtToken, cookieOptions);

    return res.json({
      message: "Signin successfully",
      user: {
        email: user.email,
        id: user._id,
      },
      success: true,
      error: false,
    });
  } catch (error) {
    return res.status(500).json({
      error: error.message,
      message: "Something went wrong",
    });
  }
};
